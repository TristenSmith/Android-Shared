# Command Line

## adb logcat ReceiveActivity:* MainActivity:* *:S
